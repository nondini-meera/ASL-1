#include <WiFi.h>
#include <HTTPClient.h>

const int SENSOR_PIN = 4;   
const int LED_PIN = 2;      

const char* ssid = "Wokwi-GUEST";
const char* password = "";

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected to WiFi!");
}

void loop() {
  int sensorValue = analogRead(SENSOR_PIN);
  
  Serial.print("Sensor Value: ");
  Serial.println(sensorValue);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    String serverPath = "http://httpbin.org/get?sensor=" + String(sensorValue);
    
    http.begin(serverPath.c_str());
    int httpResponseCode = http.GET();
    
    if (httpResponseCode > 0) {
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
    } else {
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  }

  REG_WRITE(GPIO_OUT_W1TS_REG, (1 << LED_PIN));
  delay(1500); 

  REG_WRITE(GPIO_OUT_W1TC_REG, (1 << LED_PIN));
  delay(1500); 
}
