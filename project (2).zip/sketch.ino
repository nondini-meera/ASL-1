#include <WiFi.h>
#include <PubSubClient.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "broker.hivemq.com";

WiFiClient espClient;
PubSubClient client(espClient);

const int BTN1_PIN = 34;
const int BTN2_PIN = 27;
const int LED1_PIN = 25;
const int LED2_PIN = 26;

bool led1State = false;
bool led2State = false;

void callback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (unsigned int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  if (String(topic) == "wokwi/home/relay1") {
    if (message == "ON") led1State = true;
    else if (message == "OFF") led1State = false;
    digitalWrite(LED1_PIN, led1State);
  }
  else if (String(topic) == "wokwi/home/relay2") {
    if (message == "ON") led2State = true;
    else if (message == "OFF") led2State = false;
    digitalWrite(LED2_PIN, led2State);
  }
}

void reconnect() {
  while (!client.connected()) {
    if (client.connect("ESP32Client_SmartHome")) {
      client.subscribe("wokwi/home/relay1");
      client.subscribe("wokwi/home/relay2");
    } else {
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED1_PIN, OUTPUT);
  pinMode(LED2_PIN, OUTPUT);
  
  // শুরুতে সব লাইট বন্ধ থাকবে
  digitalWrite(LED1_PIN, LOW);
  digitalWrite(LED2_PIN, LOW);

  pinMode(BTN1_PIN, INPUT);        
  pinMode(BTN2_PIN, INPUT_PULLUP); 

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
  
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  uint32_t gpio_in = REG_READ(GPIO_IN_REG);
  
  bool btn1Pressed = (gpio_in & (1 << BTN1_PIN));
  bool btn2Pressed = !(gpio_in & (1 << BTN2_PIN));

  static bool lastBtn1 = false;
  static bool lastBtn2 = false;

  if (btn1Pressed && !lastBtn1) {
    led1State = !led1State;
    digitalWrite(LED1_PIN, led1State);
    client.publish("wokwi/home/relay1", led1State ? "ON" : "OFF");
    delay(200);
  }
  lastBtn1 = btn1Pressed;

  if (btn2Pressed && !lastBtn2) {
    led2State = !led2State;
    digitalWrite(LED2_PIN, led2State);
    client.publish("wokwi/home/relay2", led2State ? "ON" : "OFF");
    delay(200);
  }
  lastBtn2 = btn2Pressed;
}