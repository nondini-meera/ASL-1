const int BTN_PIN = 12; // Pin 12 তে বাটন কানেক্ট করা
uint8_t counter = 0;    // বাইনারি কাউন্টার (0 থেকে 15 পর্যন্ত)

void setup() {
  Serial.begin(9600);

  // Pin 8 থেকে 11 পর্যন্ত আউটপুট হিসেবে সেট করার জন্য DDRB রেজিস্টার কনফিগার করা
  // Bit 0 to 3 (Pins 8, 9, 10, 11) আউটপুট (1) হবে
  DDRB |= (1 << DDB0) | (1 << DDB1) | (1 << DDB2) | (1 << DDB3);

  // Pin 12 (PB4) ইনপুট হিসেবে সেট হবে এবং ইন্টারনাল পুল-আপ রেজিস্টার অন থাকবে
  DDRB &= ~(1 << DDB4);
  PORTB |= (1 << PORTB4);
}

void loop() {
  // PINB রেজিস্টার থেকে সরাসরি Pin 12 এর স্টেট রিড করা (পুল-আপ থাকায় না চাপলে HIGH, চাপলে LOW)
  bool btnPressed = !(PINB & (1 << PINB4));

  static bool lastBtnState = false;

  // বাটন প্রেস করলে কাউন্ট ১ বাড়াবে এবং 15 এর மேல் গেলে আবার 0 হয়ে যাবে
  if (btnPressed && !lastBtnState) {
    counter = (counter + 1) % 16;
    
    // PORTB রেজিস্টারের মাধ্যমে একসাথে পিন ৮ থেকে ১১ তে বাইনারি ভ্যালু পাঠানো
    // (PORTB এর লোয়ার ৪ বিটে কাউন্টারের মান বসানো হচ্ছে)
    PORTB = (PORTB & 0xF0) | (counter & 0x0F);

    Serial.print("Counter: ");
    Serial.println(counter);

    delay(50); // ছোট ডিবাউন্সিং ডিলে
  }
  
  lastBtnState = btnPressed;
}