int speed = 200; // প্রাথমিক গতি (மில்িসেকেন্ড)

void setup() {
  Serial.begin(9600);

  // পিন ৪, ৫, ৬ এবং ৭ (PORTD-এর বিট ৪ থেকে ৭) আউটপুট হিসেবে কনফিগার করা
  // DDRD রেজিস্টারের মাধ্যমে পিন ৪-৭ কে আউটপুট (1) করা হচ্ছে
  DDRD |= (1 << DDD4) | (1 << DDD5) | (1 << DDD6) | (1 << DDD7);
}

void loop() {
  // সিরিয়াল মনিটর থেকে ইনপুট চেক করা
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == 'f' || cmd == 'F') {
      speed = max(50, speed - 50); // গতি বাড়ানো (সর্বনিম্ন ৫০ মি.সে.)
      Serial.print("New Speed: ");
      Serial.print(speed);
      Serial.println(" ms");
    } 
    else if (cmd == 's' || cmd == 'S') {
      speed += 50; // গতি কমানো
      Serial.print("New Speed: ");
      Serial.print(speed);
      Serial.println(" ms");
    }
  }

  // পিন ৪ থেকে ৭ পর্যন্ত স্ক্যানার লজিক (आगे যাওয়া)
  for (int i = 4; i <= 7; i++) {
    PORTD = (1 << i); // নির্দিষ্ট পিনটি অন করা এবং বাকিগুলো অফ করা
    delay(speed);
  }

  // পিন ৬ থেকে ৪ পর্যন্ত ফিরে আসা (পেছনে যাওয়া)
  for (int i = 6; i >= 5; i--) {
    PORTD = (1 << i);
    delay(speed);
  }
}
