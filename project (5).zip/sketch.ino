#include <WiFi.h>
#include <DHTesp.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const int DHT_PIN = 15;
const int BTN_PIN = 4;
const int FAN_PIN = 2;

DHTesp dht;

unsigned long lastMillis = 0;
const long interval = 2000; // প্রতি ২ সেকেন্ডে একবার টেম্পারেচার রিড করার জন্য

bool fanState = false;
bool lastBtnState = HIGH;

void setup() {
  Serial.begin(115200);
  
  pinMode(FAN_PIN, OUTPUT);
  digitalWrite(FAN_PIN, LOW);

  pinMode(BTN_PIN, INPUT_PULLUP); // ইন্টারনাল পুল-আপ অন করা হলো

  dht.setup(DHT_PIN, DHTesp::DHT22);

  // ওয়াইফাই কানেকশন
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Connected!");
}

void loop() {
  // ১. জিরো লেগ (Under 50ms) রেসপন্সের জন্য পুশ-বাটন ইনস্ট্যান্ট চেক করা
  bool currentBtnState = digitalRead(BTN_PIN);
  if (currentBtnState == LOW && lastBtnState == HIGH) {
    fanState = !fanState; // ফ্যানের স্টেট টগল করা (অন/অফ)
    digitalWrite(FAN_PIN, fanState ? HIGH : LOW);
    Serial.print("Emergency Override! Fan State: ");
    Serial.println(fanState ? "ON" : "OFF");
    delay(50); // ছোট ডিবাউন্স ডিলে
  }
  lastBtnState = currentBtnState;

  // ২. প্রতি ২ সেকেন্ড পর পর সেন্সর থেকে টেম্পারেচার ও হিউমিডিটি রিড করা
  unsigned long currentMillis = millis();
  if (currentMillis - lastMillis >= interval) {
    lastMillis = currentMillis;

    TempAndHumidity data = dht.getTempAndHumidity();
    
    Serial.print("Temp: ");
    Serial.print(data.temperature);
    Serial.print("°C  Humidity: ");
    Serial.print(data.humidity);
    Serial.println("%");
  }
}